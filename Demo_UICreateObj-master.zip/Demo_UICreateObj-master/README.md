# Demo_UICreateObj
点击UI生成模型演示

![image](https://github.com/KingSun5/Demo_UICreateObj/blob/master/images/1.gif)